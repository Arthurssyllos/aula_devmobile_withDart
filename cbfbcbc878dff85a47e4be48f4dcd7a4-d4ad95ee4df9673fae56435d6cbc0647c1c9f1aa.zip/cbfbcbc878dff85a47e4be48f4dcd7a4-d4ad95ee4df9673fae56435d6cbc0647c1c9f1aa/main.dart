
// Exemplo de recursão para resolução do problema de potenciação:

/*void main() {
 
  //comentario de uma linha
  
  int valorRetorno = calculaPotencia(base: 2, expoente: 3);
  print("Resultado: $valorRetorno");
}

int calculaPotencia({required int base, int expoente = 2 }){
  
  if ( expoente == 0 ){
    return 1;
  }
  
  if (expoente == 1){
    return base;
  }
  
  return base * calculaPotencia(base: base, expoente: expoente - 1);  
  
  /*
  for(int i = 0; i < expoente; i++ ){
    valorDeRetorno *= base;
  }
  */
  
//  return valorDeRetorno;
  
}*/

// ---------------------------------------------------

// Resolução do exercício de número fatorial!

/*int calcularFatorial(int n) {
  if (n == 0) {
    // O fatorial de 0 é 1, então retornamos 1.
    return 1;
  } 
    // Chamamos a função recursivamente para calcular o fatorial de (n-1)
    // e multiplicamos o resultado por n para obter o fatorial de n.
    return n * calcularFatorial(n - 1);
  
}

void main() {
  int numero = 4; // Substitua 5 pelo número desejado.
  int fatorial = calcularFatorial(numero);
  print("O fatorial de $numero é $fatorial");
} */

// ---------------------------------------------------


// Resolução expressão de multiplicação por somas sucessivas.

/*
int multiplicacaoPorSomasSucessivas(int a, int b) {
  if (b == 0) {
    // Qualquer número multiplicado por 0 é 0.
    return 0;
  } else if (b == 1) {
    // Qualquer número multiplicado por 1 é igual a ele mesmo.
    return a;
  } else {
    // Chamamos a função recursivamente para somar 'a' a si mesmo (b-1) vezes.
    return a + multiplicacaoPorSomasSucessivas(a, b - 1);
  }
}

void main() {
  int numero1 = 7; // Substitua pelo primeiro número.
  int numero2 = 4; // Substitua pelo segundo número.

  int resultado = multiplicacaoPorSomasSucessivas(numero1, numero2);

  print("$numero1 * $numero2 = $resultado");
}*/
